import React from 'react';

 
const signout = () => {
  return(
    <div className="container">
        <div className="py-4">
           <h3 class="font-weight-bold" style={{ color: "blue"}}> Signed Out Successfully..... </h3>
        </div>
      </div>
  );
};
export default signout;   