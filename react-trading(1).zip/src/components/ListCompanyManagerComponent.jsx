import React, { Component } from 'react'
import CompanyManagerAdminService from '../services/CompanyManagerAdminService'

class ListCompanyManagerComponent extends Component {
    constructor(props) {
        super(props)

        this.state = {
                companymanagers: []
        }
        this.addCompanyManager = this.addCompanyManager.bind(this);
        this.editCompanyManager = this.editCompanyManager.bind(this);
        this.deleteCompanyManager = this.deleteCompanyManager.bind(this);
    }

    deleteCompanyManager(companyManagerId){
        CompanyManagerAdminService.deleteCompanyManager(companyManagerId).then( res => {
            this.setState({companymanagers: this.state.companymanagers.filter(companymanager => companymanager.companyManagerId !== companyManagerId)});
        });
    }
    viewCompanyManager(companyManagerId){
        this.props.history.push(`/view-companymanager/${companyManagerId}`);
    }
    
    editCompanyManager(companyManagerId){
        this.props.history.push(`/update-companymanager/${companyManagerId}`);
    }

    componentDidMount(){
        CompanyManagerAdminService.getCompanyManager().then((res) => {
            this.setState({ companymanagers: res.data});
        });
    }

    addCompanyManager(){
        this.props.history.push('/add-companymanager');
    }

    render() {
        return (
            <div>
                 <h2 className="text-center">CompanyManagers List</h2>
                 <div className = "row">
                    <button className="btn btn-primary" onClick={this.addCompanyManager}> Add CompanyManager</button>
                 </div>
                 <br></br>
                 <div className = "row">
                        <table className = "table table-striped table-bordered">

                          <thead class="thead-dark">
                                <tr>
                                <th>Id</th>
                                    <th> Company Name</th>
                                    <th> Email</th>
                                    <th> Phone</th>
                                    <th> Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                {
                                    this.state.companymanagers.map(
                                        companymanager => 
                                        <tr key = {companymanager.companyManagerId}>
                                           <td> { companymanager.companyManagerId} </td>   
                                             <td> { companymanager.companyManagerCompanyName} </td>   
                                             <td> {companymanager.companyManagerEmail}</td>
                                             <td> {companymanager.companyManagerPhone}</td>
                                             <td>
                                                 <button onClick={ () => this.editCompanyManager(companymanager.companyManagerId)} className="btn btn-info">Update </button>
                                                 <button style={{marginLeft: "10px"}} onClick={ () => this.deleteCompanyManager(companymanager.companyManagerId)} className="btn btn-danger"><i class="far fa-trash-alt"></i>Delete </button>
                                                 <button style={{marginLeft: "10px"}} onClick={ () => this.viewCompanyManager(companymanager.companyManagerId)} className="btn btn-info">View </button>
                                             </td>
                                        </tr>
                                    )
                                }
                            </tbody>
                        </table>

                 </div>

            </div>
        )
    }
}

export default ListCompanyManagerComponent



