import React from 'react';
 
const Home = () => {
  return(
    <div className="container">
        <div className="py-4">
           <h3  style={{color: "blue"}}> Trade from anywhere at your fingertips with Trading Service Application</h3>
           <div class="text-center">
           <img src="trading.jpg" class="img-fluid .w-100" alt="Responsive image"></img>
        </div>
      </div>
      </div>
  );
};
export default Home;   