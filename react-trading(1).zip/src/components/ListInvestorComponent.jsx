import React, { Component } from 'react'
import InvestorAdminService from '../services/InvestorAdminService'


class ListInvestorComponent extends Component {
    constructor(props) {
        
        super(props)

        this.state = {
                investors: []
        }

        this.addInvestor = this.addInvestor.bind(this);
        this.updateInvestor = this.updateInvestor.bind(this);
        this.deleteInvestor = this.deleteInvestor.bind(this);
    }


    deleteInvestor(investorId){
        InvestorAdminService.deleteInvestor(investorId).then( res => {
            this.setState({investors: this.state.investors.filter(investor => investor.investorId !== investorId)});
        });
    }
    deleteInvestor(investorId){
        const investors=this.state.investors.filter(investor => investor.investorId == investorId);
        this.setState({
            investors:investors
        })

    }
    
    viewInvestor(investorId){
        this.props.history.push(`/view-investor/${investorId}`);
    }

    updateInvestor(investorId){
        this.props.history.push(`/update-investor/${investorId}`);
    }

    componentDidMount(){
        InvestorAdminService.getInvestor().then((res) => {
            this.setState({ investors: res.data});
        });
    } 

    addInvestor(){
        this.props.history.push('/add-investor');
    }

    render() {
        return (
            
            <div>
                 <h2 className="text-center">Investors List</h2>
                 <div className = "row">
                    <button className="btn btn-primary" onClick={this.addInvestor}> Add Investor</button>
                 </div>
                 <br></br>
                 <div className = "row">
                        <table className = "table table-striped table-bordered">

                        <thead class="thead-dark">
                                <tr>
                                <th>Id </th>
                                    <th>Name </th>
                                    <th>Pan Number</th>
                                    <th>Email</th>
                                    <th> Phone </th>
                                    <th> Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                {
                                    this.state.investors.map(
                                        investor => 
                                        <tr key = {investor.investorId}>
                                               <td> { investor.investorId} </td>   
                                             <td> { investor.investorName} </td>   
                                             <td> {investor.investorPannum}</td>
                                             <td> {investor.investorEmail}</td>
                                             <td> {investor.investorPhone}</td>
                                             <td>
                                                 <button onClick={ () => this.updateInvestor(investor.investorId)} className="btn btn-info">Update </button>
                                                 <button style={{marginLeft: "10px"}} onClick={ () => this.deleteInvestor(investor.investorId)} className="btn btn-danger">Delete </button>
                                                 <button style={{marginLeft: "10px"}} onClick={ () => this.viewInvestor(investor.investorId)} className="btn btn-info">View </button>
                                             </td>
                                        </tr>
                                    )
                                }
                            </tbody>
                        </table>

                 </div>

            </div>
           
        )
    }
}

export default ListInvestorComponent

