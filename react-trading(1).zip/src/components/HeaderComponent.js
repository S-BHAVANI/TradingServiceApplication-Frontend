import React, { Component } from 'react'
import {Nav,Navbar,NavDropdown} from 'react-bootstrap';
import { NavLink } from 'react-router-dom';

class HeaderComponent extends Component {
    constructor(props) {
        super(props)

        this.state = {
                 
        }
    }

    render() {
        return (
            <div>
                <header>
                <nav className="navbar navbar-expand-md navbar-dark bg-info">
                    <div><NavLink activeclassName="active" exact to='/'  className="navbar-brand">Trading Service Application</NavLink></div>
                    <div><NavLink activeclassName="active" exact to='/'  className="navbar-brand">Home</NavLink></div>
                    <div><NavLink activeclassName="active" exact to="/CompanyManager" className="navbar-brand">Manager</NavLink></div>
                    <div><NavLink activeclassName="active" exact to="/Investor" className="navbar-brand">Investor</NavLink></div>
                    <div><NavLink activeclassName="active" exact to="/Stock" className="navbar-brand">Stock</NavLink></div>
        
                   <Navbar.Toggle aria-controls="responsive-navbar-nav" />
                   <Navbar.Collapse id="responsive-navbar-nav"> 
                   </Navbar.Collapse>
                   <div><NavLink activeclassName="active" exact to="/Profile" className="navbar-brand">My Profile</NavLink></div>
                   <div><NavLink activeclassName="active" exact to="/signout" className="navbar-brand">Sign Out</NavLink></div>
        
             </nav>
             </header>
            </div>
        )
    }
}

export default HeaderComponent
