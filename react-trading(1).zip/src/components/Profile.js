import React from 'react';

 
const Profile = () => {
  return(
    <div className="card col-md-4 offset-md-4">
        <div className="py-4">
        <div class="card  text-white bg-secondary mb-3" >
        <img src="images2.png"></img>
         <div class="card-body">
         <h5 class="card-title">Bhavani</h5>
          <h6 class="card-text">Role: Admin</h6>
          <p class="card-text">Actions: Performs Curd operations on Investor and Company Manager .</p>
            
          </div>
        
          </div>
      </div>
      </div>
  );
};
export default Profile;   